package com.example.gift.newsreader;

/**
 * Created by Gift on 25-Apr-17.
 */

public class News {

    String title;
    String description;
    String url;

    public News(String head, String desc, String url) {
        title = head;
        description = desc;
        this.url = url;
    }

    public String getTitle() {
        return title;
    }

    public String getDescription() {
        return description;
    }

    public String getUrl() {
        return url;
    }
}
