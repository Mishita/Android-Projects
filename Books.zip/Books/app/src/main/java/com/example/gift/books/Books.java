package com.example.gift.books;

/**
 * Created by Gift on 02-May-17.
 */
public class Books {

    private String mBook;
    private String mAuthor;
    private  String mUrl;

    public Books(String book, String author ) {

        mAuthor = author;
        mBook = book;
      //  mUrl = url;
    }

    public String getmBook() {
        return mBook;
    }

    public String getmAuthor() {
        return mAuthor;
    }

    public String getUrl() {
        return mUrl;
    }
}
