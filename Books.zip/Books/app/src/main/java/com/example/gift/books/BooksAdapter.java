package com.example.gift.books;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.List;

/**
 * Created by Gift on 02-May-17.
 */

public class BooksAdapter extends ArrayAdapter<Books> {

    public BooksAdapter(Context context, List<Books> bookses) {
        super(context, 0, bookses);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View listItemView = convertView;
        if (listItemView == null) {
            listItemView = LayoutInflater.from(getContext()).inflate(
                    R.layout.activity_book_list, parent, false);
        }

        Books currentBook = getItem(position);
        TextView book = (TextView) listItemView.findViewById(R.id.book_name);
        book.setText(currentBook.getmBook());
        TextView author = (TextView) listItemView.findViewById(R.id.author_name);
        author.setText(currentBook.getmAuthor());
        return listItemView;
    }


}
