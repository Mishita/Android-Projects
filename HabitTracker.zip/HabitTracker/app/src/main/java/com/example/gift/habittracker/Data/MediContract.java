package com.example.gift.habittracker.Data;

import android.provider.BaseColumns;

/**
 * Created by Gift on 06-May-17.
 */

public final class MediContract {

    private MediContract(){}

    public static final class MediEntry implements BaseColumns {

        public final static String TABLE_NAME = "mediciene";
        public final static String _ID = BaseColumns._ID;
        public final static String COLUMN_NAME = "name";
        public final static String COLUMN_TIME = "time";
        public final static String COLUMN_TYPE = "type";

        public final static int TYPE_TABLET = 3;
        public final static int TYPE_SYRUP = 1;
        public final static int TYPE_INJECTION = 2;
        public final static int TYPE_UNKNOWN = 0;
    }

}
