package com.example.gift.habittracker;

import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v4.app.NavUtils;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.example.gift.habittracker.Data.MediContract;
import com.example.gift.habittracker.Data.MediDbHelper;

/**
 * Created by Gift on 06-May-17.
 */

public class EditorActivity extends AppCompatActivity {

    private EditText mNameEditText;
    private EditText mTimeEditText;
    private Spinner mTypeSpinner;
    private int mType = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_editor);

        mNameEditText = (EditText) findViewById(R.id.edit_name);
        mTimeEditText = (EditText) findViewById(R.id.edit_time);
        mTypeSpinner = (Spinner) findViewById(R.id.spinner_type);

        setupSpinner();
    }

    private void setupSpinner() {
        ArrayAdapter genderSpinnerAdapter = ArrayAdapter.createFromResource(this,
                R.array.array_type_options, android.R.layout.simple_spinner_item);

        genderSpinnerAdapter.setDropDownViewResource(android.R.layout.simple_dropdown_item_1line);

        mTypeSpinner.setAdapter(genderSpinnerAdapter);

        mTypeSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String selection = (String) parent.getItemAtPosition(position);
                if (!TextUtils.isEmpty(selection)) {
                    if (selection.equals(getString(R.string.type_tablet))) {
                        mType = MediContract.MediEntry.TYPE_TABLET;
                    } else if (selection.equals(getString(R.string.type_injection))) {
                        mType = MediContract.MediEntry.TYPE_INJECTION;
                    } else if (selection.equals(getString(R.string.type_syrup))) {
                        mType = MediContract.MediEntry.TYPE_SYRUP;
                    } else {
                        mType = MediContract.MediEntry.TYPE_UNKNOWN;
                    }
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                mType = 0; // Unknown
            }
        });
    }


    private void insertTrack() {
        String nameString = mNameEditText.getText().toString().trim();
        String timeString = mTimeEditText.getText().toString().trim();

        MediDbHelper mDbHelper = new MediDbHelper(this);
        SQLiteDatabase db = mDbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(MediContract.MediEntry.COLUMN_NAME, nameString);
        values.put(MediContract.MediEntry.COLUMN_TIME, timeString);
        values.put(MediContract.MediEntry.COLUMN_TYPE, mType);

        long newRowId = db.insert(MediContract.MediEntry.TABLE_NAME, null, values);
        if (newRowId == -1) {
            Toast.makeText(this, "Error saving Track ", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Track saved with id : " + newRowId, Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_editor, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_save:
                insertTrack();
                finish();
                return true;
            case R.id.action_delete:
                return true;
            case android.R.id.home:
                NavUtils.navigateUpFromSameTask(this);
                return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
