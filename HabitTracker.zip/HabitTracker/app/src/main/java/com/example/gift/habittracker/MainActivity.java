package com.example.gift.habittracker;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.example.gift.habittracker.Data.MediContract;
import com.example.gift.habittracker.Data.MediDbHelper;

public class MainActivity extends AppCompatActivity {

    private MediDbHelper mDbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button fab = (Button) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, EditorActivity.class);
                startActivity(intent);
            }
        });

        mDbHelper = new MediDbHelper(this);

        displayDatabaseInfo();
    }

    @Override
    protected void onStart() {
        super.onStart();
        displayDatabaseInfo();
    }


    private void displayDatabaseInfo() {
        MediDbHelper mDbHelper = new MediDbHelper(this);



        Cursor cursor = getCursor();
        TextView displayView = (TextView) findViewById(R.id.text_view_pet);

        try {

            displayView.setText("The table contains " + cursor.getCount() + "tracks.\n\n");
            displayView.append(MediContract.MediEntry._ID + " - " +
                    MediContract.MediEntry.COLUMN_NAME + " - " +
                    MediContract.MediEntry.COLUMN_TIME + " - " +
                    MediContract.MediEntry.COLUMN_TIME + " - " +
                    "\n");

            int idColumnIndex = cursor.getColumnIndex(MediContract.MediEntry._ID);
            int nameColumnIndex = cursor.getColumnIndex(MediContract.MediEntry.COLUMN_NAME);
            int timeColumnIndex = cursor.getColumnIndex(MediContract.MediEntry.COLUMN_TIME);
            int typeColumnIndex = cursor.getColumnIndex(MediContract.MediEntry.COLUMN_TYPE);

            while (cursor.moveToNext()) {

                int currentId = cursor.getInt(idColumnIndex);
                String currentName = cursor.getString(nameColumnIndex);
                String currentTime = cursor.getString(timeColumnIndex);
                int currentType = cursor.getInt(typeColumnIndex);

                displayView.append(("\n" + currentId + " - " +
                        currentName + " - " +
                        currentTime + " - " +
                        currentType + " - "
                ));
            }

        } finally {
            cursor.close();

        }
    }

    private void insertTrack() {
        SQLiteDatabase db = mDbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(MediContract.MediEntry.COLUMN_NAME, "ABC");
        values.put(MediContract.MediEntry.COLUMN_TIME, "7am");
        values.put(MediContract.MediEntry.COLUMN_TYPE, MediContract.MediEntry.TYPE_TABLET);

        long insert = db.insert(MediContract.MediEntry.TABLE_NAME, null, values);
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_insert_dummy_data:
                insertTrack();
                displayDatabaseInfo();
                return true;
            case R.id.action_delete_all_entries:

                return true;
        }
        return super.onOptionsItemSelected(item);
    }

    Cursor getCursor()
    {
        SQLiteDatabase db = mDbHelper.getReadableDatabase();

        String[] projection = {
                MediContract.MediEntry._ID,
                MediContract.MediEntry.COLUMN_NAME,
                MediContract.MediEntry.COLUMN_TIME,
                MediContract.MediEntry.COLUMN_TYPE
        };

        Cursor cursor = db.query(
                MediContract.MediEntry.TABLE_NAME,
                projection,
                null,
                null,
                null,
                null, null
        );
        return cursor;
    }
}
