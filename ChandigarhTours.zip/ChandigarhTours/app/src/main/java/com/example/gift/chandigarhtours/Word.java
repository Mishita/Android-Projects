package com.example.gift.chandigarhtours;

/**
 * Created by Gift on 03-Apr-17.
 */

public class Word {

    int mImageResourceId;
    int NO_IMAGE_PROVIDED = -1;
    String mDefault;
    public int getmImageResourceId() {
        return mImageResourceId;
    }

    public boolean hasImage() {
        return mImageResourceId != NO_IMAGE_PROVIDED;
    }
public String getmDefault(){
    return mDefault;
}

    public Word(String defaultT) {
        mDefault = defaultT;
    }
    public Word(String defaultT, int imageResourceId) {
        mDefault = defaultT;
        mImageResourceId = imageResourceId;

    }
}
