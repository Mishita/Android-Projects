package com.example.gift.chandigarhtours;

/**
 * Created by Gift on 05-Apr-17.
 */

public class transport_class {
    String transportName;
    private static final int NO_IMAGE_PROVIDED = -1;
    private int mImageResourceId = NO_IMAGE_PROVIDED;


    public transport_class(String s,int mImageResourceId) {
        transportName = s;
        this.mImageResourceId = mImageResourceId;
    }

    public void setGname(String transportName) {
        this.transportName = transportName;
    }

    public String getGname() {
        return transportName;
    }

    public int getmImageResourceId() {
        return mImageResourceId;
    }

    public boolean hasImage() {
        return mImageResourceId != NO_IMAGE_PROVIDED;
    }

}
