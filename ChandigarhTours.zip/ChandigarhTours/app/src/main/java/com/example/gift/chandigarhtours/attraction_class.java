package com.example.gift.chandigarhtours;

/**
 * Created by Gift on 05-Apr-17.
 */

public class attraction_class {
    String attractName;

    public attraction_class(String s) {
        attractName = s;
    }

    public void setGname(String attractName) {
        this.attractName = attractName;
    }

    public String getGname() {
        return attractName;
    }
}
