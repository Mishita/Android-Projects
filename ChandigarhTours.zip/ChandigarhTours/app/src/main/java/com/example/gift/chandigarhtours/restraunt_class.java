package com.example.gift.chandigarhtours;

/**
 * Created by Gift on 05-Apr-17.
 */

public class restraunt_class {
    String restrauntName;

    public restraunt_class(String s) {
        restrauntName = s;
    }

    public void setGname(String restrauntName) {
        this.restrauntName = restrauntName;
    }

    public String getGname() {
        return restrauntName;
    }
}
