package com.example.gift.chandigarhtours;

/**
 * Created by Gift on 05-Apr-17.
 */

public class malls_class {
    String mallName;

    public malls_class(String s) {
        mallName = s;
    }

    public void setGname(String mallName) {
        this.mallName = mallName;
    }

    public String getGname() {
        return mallName;
    }
}
