package com.example.gift.chandigarhtours;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ListView;

import java.util.ArrayList;

public class Restraunts extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.word_list);

        final ArrayList<restraunt_class> word = new ArrayList<restraunt_class>();
        word.add(new restraunt_class(getResources().getString(R.string.saffron)));
        word.add(new restraunt_class(getResources().getString(R.string.lalit)));
        word.add(new restraunt_class(getResources().getString(R.string.cafe)));
        word.add(new restraunt_class(getResources().getString(R.string.oregano)));
        word.add(new restraunt_class(getResources().getString(R.string.bbq)));
        word.add(new restraunt_class(getResources().getString(R.string.gopal)));
        word.add(new restraunt_class(getResources().getString(R.string.virgin)));
        word.add(new restraunt_class(getResources().getString(R.string.sindhi)));
        word.add(new restraunt_class(getResources().getString(R.string.chillis)));
        restrauntAdapter adapter = new restrauntAdapter(this, word, R.color.category_phrases);
        ListView listView = (ListView) findViewById(R.id.List);
        listView.setAdapter(adapter);
    }
    }
