package com.example.gift.chandigarhtours;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import java.util.ArrayList;

public class Attractions extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.word_list);

        final ArrayList<attraction_class> word = new ArrayList<attraction_class>();
        word.add(new attraction_class((getResources().getString(R.string.lake))));
        word.add(new attraction_class(getResources().getString(R.string.sec_17)));
        word.add(new attraction_class(getResources().getString(R.string.chatt)));
        word.add(new attraction_class(getResources().getString(R.string.Leisure)));
        word.add(new attraction_class(getResources().getString(R.string.capitol)));
        word.add(new attraction_class(getResources().getString(R.string.fun)));
        word.add(new attraction_class(getResources().getString(R.string.inter)));
        word.add(new attraction_class(getResources().getString(R.string.govt)));

        attractionAdapter adapter = new attractionAdapter(this, word, R.color.colorAccent);
        ListView listView = (ListView) findViewById(R.id.List);
        listView.setAdapter(adapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                switch (position) {
                    case 0:
                        Intent firstIntent = new Intent(Attractions.this, Sukhna_lake.class);
                        startActivity(firstIntent);
                        break;
                    case 1:
                        Intent secondIntent = new Intent(Attractions.this, sector_17.class);
                        startActivity(secondIntent);
                        break;

                    case 2:
                        Intent thirdIntent = new Intent(Attractions.this, chattbir_zoo.class);
                        startActivity(thirdIntent);
                        break;
                    case 3:
                        Intent fourthIntent = new Intent(Attractions.this, Leisure_valley.class);
                        startActivity(fourthIntent);
                        break;
                    case 4:
                        Intent fifthIntent = new Intent(Attractions.this, capitol_complex.class);
                        startActivity(fifthIntent);
                        break;
                    case 5:
                        Intent sixthIntent = new Intent(Attractions.this, funcity.class);
                        startActivity(sixthIntent);
                        break;
                    case 6:
                        Intent seventhIntent = new Intent(Attractions.this, international_doll_museum.class);
                        startActivity(seventhIntent);
                        break;
                    case 7:
                        Intent eighthIntent = new Intent(Attractions.this, govt_museum.class);
                        startActivity(eighthIntent);
                        break;
                }


            }
        });
    }
}
