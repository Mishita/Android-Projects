package com.example.gift.chandigarhtours;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class fitness_trail_park extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fitness_trail_park);
    }
}
