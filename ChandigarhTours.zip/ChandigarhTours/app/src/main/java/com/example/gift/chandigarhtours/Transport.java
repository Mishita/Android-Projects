package com.example.gift.chandigarhtours;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ListView;

import java.util.ArrayList;

public class Transport extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.word_list);

        final ArrayList<transport_class> word = new ArrayList<transport_class>();
        word.add(new transport_class(getResources().getString(R.string.bus),R.drawable.bus));
        word.add(new transport_class(getResources().getString(R.string.auto),R.drawable.autoi));
        word.add(new transport_class(getResources().getString(R.string.taxi),R.drawable.taxi));
        word.add(new transport_class(getResources().getString(R.string.cab),R.drawable.cab));
        word.add(new transport_class(getResources().getString(R.string.rental),R.drawable.rent));
        transportAdapter adapter = new transportAdapter(this, word, R.color.category_colors);
        ListView listView = (ListView) findViewById(R.id.List);
        listView.setAdapter(adapter);
    }
    }

