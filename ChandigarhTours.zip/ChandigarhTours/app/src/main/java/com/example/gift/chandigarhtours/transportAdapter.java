package com.example.gift.chandigarhtours;

import android.app.Activity;
import android.support.annotation.NonNull;
import android.support.v4.content.ContextCompat;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by Gift on 05-Apr-17.
 */

public class transportAdapter extends ArrayAdapter<transport_class> {
    private int mColorResourceId;
    private static final int NO_IMAGE_PROVIDED = -1;
    private int mImageResourceId = NO_IMAGE_PROVIDED;


    public transportAdapter(Activity context, ArrayList<transport_class> mall, int colorResourceId) {
        super(context, 0, mall);
        mColorResourceId = colorResourceId;
    }

    @NonNull
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View listItemView = convertView;
        if (listItemView == null) {
            listItemView = LayoutInflater.from(getContext()).inflate(
                    R.layout.list_garden, parent, false);
        }
        transport_class current = getItem(position);
        TextView chandigarhTextView = (TextView) listItemView.findViewById(R.id.chandigarh_text_view);

        chandigarhTextView.setText(current.getGname());
        View textContainer = listItemView.findViewById(R.id.image_container);

        int color = ContextCompat.getColor(getContext(), mColorResourceId);
        textContainer.setBackgroundColor(color);

        ImageView iconView = (ImageView) listItemView.findViewById(R.id.image);
        if (current.hasImage()) {

            iconView.setImageResource(current.getmImageResourceId());
            iconView.setVisibility(View.VISIBLE);
        }
        else {
            iconView.setVisibility(View.GONE);
        }

        return listItemView;
    }
}
