package com.example.gift.chandigarhtours;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class rose_garden extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.rose_garden);
    }
}
