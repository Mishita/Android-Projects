package com.example.gift.chandigarhtours;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import java.util.ArrayList;

public class Gardens extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.word_list);

        final ArrayList<garden_class> word = new ArrayList<garden_class>();
        word.add(new garden_class(getResources().getString(R.string.rose_garden)));
        word.add(new garden_class(getResources().getString(R.string.bougain)));
        word.add(new garden_class(getResources().getString(R.string.top)));
        word.add(new garden_class(getResources().getString(R.string.rock_garden)));
        word.add(new garden_class(getResources().getString(R.string.shanti)));
        word.add(new garden_class(getResources().getString(R.string.children)));
        word.add(new garden_class(getResources().getString(R.string.butterfly_park)));
        word.add(new garden_class(getResources().getString(R.string.fit)));

        gardenAdapter adapter = new gardenAdapter(this, word, R.color.category_numbers);
        ListView listView = (ListView) findViewById(R.id.List);
        listView.setAdapter(adapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                switch (position) {
                    case 0:
                        Intent firstIntent = new Intent(Gardens.this, rose_garden.class);
                        startActivity(firstIntent);
                        break;
                    case 1:
                        Intent secondIntent = new Intent(Gardens.this, Bougainvillea_park.class);
                        startActivity(secondIntent);
                        break;

                    case 2:
                        Intent thirdIntent = new Intent(Gardens.this, topiary_park.class);
                        startActivity(thirdIntent);
                        break;
                    case 3:
                        Intent fourthIntent = new Intent(Gardens.this, rock_garden.class);
                        startActivity(fourthIntent);
                        break;
                    case 4:
                        Intent fifthIntent = new Intent(Gardens.this, shanti_kunj.class);
                        startActivity(fifthIntent);
                        break;
                    case 5:
                        Intent sixthIntent = new Intent(Gardens.this, children_traffic_park.class);
                        startActivity(sixthIntent);
                        break;
                    case 6:
                        Intent seventhIntent = new Intent(Gardens.this, butterfly_park.class);
                        startActivity(seventhIntent);
                        break;
                    case 7:
                        Intent eighthIntent = new Intent(Gardens.this, fitness_trail_park.class);
                        startActivity(eighthIntent);
                        break;
                }


            }
        });
    }
}
