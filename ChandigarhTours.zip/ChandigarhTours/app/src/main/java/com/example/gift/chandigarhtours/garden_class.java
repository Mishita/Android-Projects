package com.example.gift.chandigarhtours;

/**
 * Created by Gift on 03-Apr-17.
 */

public class garden_class {

    String gname;

    public garden_class(String s) {
         gname = s;
    }

    public void setGname(String gname) {
        this.gname = gname;
    }

    public String getGname() {
        return gname;
    }

}
