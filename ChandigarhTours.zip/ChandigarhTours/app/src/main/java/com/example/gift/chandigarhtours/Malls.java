package com.example.gift.chandigarhtours;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ListView;

import java.util.ArrayList;

public class Malls extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.word_list);

        final ArrayList<malls_class> word = new ArrayList<malls_class>();
        word.add(new malls_class(getResources().getString(R.string.Elante)));
        word.add(new malls_class(getResources().getString(R.string.shalimar)));
        word.add(new malls_class(getResources().getString(R.string.piccadilly)));
        word.add(new malls_class(getResources().getString(R.string.centra)));
        word.add(new malls_class(getResources().getString(R.string.city)));
        word.add(new malls_class(getResources().getString(R.string.pdt)));
        word.add(new malls_class(getResources().getString(R.string.north)));
        word.add(new malls_class(getResources().getString(R.string.dlf)));

        mallsAdapter adapter = new mallsAdapter(this, word, R.color.category_family);
        ListView listView = (ListView) findViewById(R.id.List);
        listView.setAdapter(adapter);
    }
    }

