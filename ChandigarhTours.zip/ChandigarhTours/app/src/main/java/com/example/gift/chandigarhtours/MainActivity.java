package com.example.gift.chandigarhtours;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        TextView attractions = (TextView) findViewById(R.id.activity_attractions);
        attractions.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent attractionsIntent = new Intent(MainActivity.this, Attractions.class);
                startActivity(attractionsIntent);
            }
        });

        TextView gardens = (TextView) findViewById(R.id.activity_gardens);
        gardens.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent gardenIntent = new Intent(MainActivity.this, Gardens.class);
                startActivity(gardenIntent);
            }
        });

        TextView malls = (TextView) findViewById(R.id.activity_malls);
        malls.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent mallsIntent = new Intent(MainActivity.this, Malls.class);
                startActivity(mallsIntent);
            }
        });

        TextView transport = (TextView) findViewById(R.id.activity_transport);
        transport.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent transportIntent = new Intent(MainActivity.this, Transport.class);
                startActivity(transportIntent);
            }
        });

        TextView restraunts = (TextView) findViewById(R.id.activity_restraunts);
        restraunts.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent restrauntsIntent = new Intent(MainActivity.this, Restraunts.class);
                startActivity(restrauntsIntent);
            }
        });
    }
}
