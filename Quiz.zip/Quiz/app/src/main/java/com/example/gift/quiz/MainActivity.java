package com.example.gift.quiz;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Toast;


public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    int count = 0;

    public void submitAnswer(View view) {
        RadioButton first = (RadioButton) findViewById(R.id.Y);
        boolean check_1 = first.isChecked();
        if (check_1 == true) {
            count = count + 1;
        }
        RadioButton second = (RadioButton) findViewById(R.id.I);
        boolean check_2 = second.isChecked();
        if (check_2 == true) {
            count = count + 1;
        }
        RadioButton third = (RadioButton) findViewById(R.id.T);
        boolean check_3 = third.isChecked();
        if (check_3 == true) {
            count = count + 1;
        }
        RadioButton fourth = (RadioButton) findViewById(R.id.C);
        boolean check_4 = fourth.isChecked();
        if (check_4 == true) {
            count = count + 1;
        }
        RadioButton fifth = (RadioButton) findViewById(R.id.B);
        boolean check_5 = fifth.isChecked();
        if (check_5 == true) {
            count = count + 1;
        }
        RadioButton sixth = (RadioButton) findViewById(R.id.T);
        boolean check_6 = sixth.isChecked();
        if (check_6 == true) {
            count = count + 1;
        }
        RadioButton seventh = (RadioButton) findViewById(R.id.T);
        boolean check_7 = seventh.isChecked();
        if (check_7 == true) {
            count = count + 1;
        }
        RadioButton eighth = (RadioButton) findViewById(R.id.M);
        boolean check_8 = eighth.isChecked();
        if (check_8 == true) {
            count = count + 1;
        }
        EditText text = (EditText) findViewById(R.id.china);
        String value = text.getText().toString();
        if (value.contentEquals("China"))
        {
            count = count + 1;
        }
        CheckBox tenth_a=(CheckBox)findViewById(R.id.i);
        CheckBox tenth_b=(CheckBox)findViewById(R.id.u);
        CheckBox tenth_c=(CheckBox)findViewById(R.id.c1);
        CheckBox tenth_d=(CheckBox)findViewById(R.id.s);
        boolean ans1_a=tenth_a.isChecked();
        boolean ans1_b=tenth_b.isChecked();
        boolean ans1_c=tenth_c.isChecked();
        boolean ans1_d=tenth_d.isChecked();
        if(ans1_a==true && ans1_b==true && ans1_c==true && ans1_d==false)
        {
            count=count+1;
        }

        Toast.makeText(this, "Your score is " + count + "/10", Toast.LENGTH_SHORT).show();
        if (count > 5) {
            Toast.makeText(this, "Well Done!!", Toast.LENGTH_SHORT).show();
        }
        else
        {
            Toast.makeText(this, "You can do better", Toast.LENGTH_SHORT).show();
        }
        count = 0;
    }
}
