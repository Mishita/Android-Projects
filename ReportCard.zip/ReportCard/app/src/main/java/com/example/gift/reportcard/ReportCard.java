package com.example.gift.reportcard;

import java.util.Scanner;

public class ReportCard {

    private String name;
    private int rollno;
    private String []subject = new String[5];
    private int []marks = new int[5];
    private float percentage;
    private int totalMarks = 0;
    Scanner s = new Scanner(System.in);

    public ReportCard(String sname,int roll,String sub[],int mark[])
    {
        name = sname;
        rollno = roll;
        subject = sub;
        marks = mark;
    }

    public void setName(String sname)
    {
        name = sname;
    }

    public String getName()
    {
        return name;
    }

    public void setRollno(int roll)
    {
        rollno = roll;
    }

    public int getRollno()
    {
        return rollno;
    }

    public void setSubject(String sub[])
    {
        subject = sub;
    }

    public String[] getSubject()
    {
        subject[0] = "English";
        subject[1] = "Science";
        subject[2] = "Maths";
        subject[3] = "Computer";
        subject[4] = "French";
        return subject;
    }
    public void setMarks(int mark[])
    {
        marks = mark;
    }

    public int[] getMarks()
    {
        for(int i = 0 ; i < 5 ; i++)
        {
            marks[0] = s.nextInt();
            totalMarks = totalMarks + marks[i];
        }
        return marks;
    }

    public float getPercentage(int totalMarks)
    {
        percentage = totalMarks / 500;
        return percentage;
    }

    @Override
    public String toString()
    {
        return "Report Card : " +
                "Roll Number : " + rollno + "\n" +
                "Name : " + name + "\n" +
                "Courses : " + "\n" +
                subject[0] + marks[0] + "\n" +
                subject[1] + marks[1] + "\n" +
                subject[2] + marks[2] + "\n" +
                subject[3] + marks[3] + "\n" +
                subject[4] + marks[4] + "\n" +
                "Percentage :  " + percentage + "\n";
    }
}
