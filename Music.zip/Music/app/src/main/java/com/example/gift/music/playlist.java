package com.example.gift.music;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.TextView;

public class playlist extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_playlist);

        TextView playing = (TextView) findViewById(R.id.nowPlaying);

        playing.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent nowPlayIntent = new Intent(playlist.this, MainActivity.class);

                startActivity(nowPlayIntent);
            }
        });


        TextView artist= (TextView) findViewById(R.id.artist);

        artist.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent artistIntent = new Intent(playlist.this, artist.class);

                startActivity(artistIntent);
            }
        });
        TextView album = (TextView) findViewById(R.id.albums);

        album.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent albumIntent = new Intent(playlist.this, album.class);

                startActivity(albumIntent);
            }
        });
    }
}
